import numpy as np
import cv2
import scipy
from matplotlib import pyplot as plt
from PIL import Image
import time
def custom_sobel(shape, axis):
    """
    shape must be odd: eg. (5,5)
    axis is the direction, with 0 to positive x and 1 to positive y
    """
    k = np.zeros(shape)
    p = [(j,i) for j in range(shape[0]) 
           for i in range(shape[1]) 
           if not (i == (shape[1] -1)/2. and j == (shape[0] -1)/2.)]

    for j, i in p:
        j_ = int(j - (shape[0] -1)/2.)
        i_ = int(i - (shape[1] -1)/2.)
        if i_ ==0 and j_==0:
            k[j,i] = 0
        else:
            k[j,i] = (i_ if axis==0 else j_)/float(i_*i_ + j_*j_)
    return k

def convolution2d(image, kernel, bias):
    m, n = kernel.shape
    if (m == n):
        y, x = image.shape
        y = y - m + 1
        x = x - m + 1
        new_image = np.zeros((y,x))
        for i in range(y):
            for j in range(x):
                new_image[i][j] = np.sum(image[i:i+m, j:j+m]*kernel) + bias
    return new_image

if __name__ == "__main__":
#(a)Fourier Transform 
    img = cv2.imread("keyboard.tif")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    size = img.shape
    img_f = np.fft.fft2(img)
    img_f = np.fft.fftshift(img_f)
    result = 20*np.log(np.abs(img_f))



#(b)Odd symmetry kernel
    kernel = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
    kernel_pad = np.zeros((4,4))
    for i in range(4):
        for j in range(4):
            if i>=1 and j>=1:
                kernel_pad[i][j] = kernel[i-1][j-1]
    print("orginal kernel")
    print(kernel)
    print("Enforced symmetry kernel")
    print(kernel_pad)

 #(c)frequency-domain filtering
    start1 = time.time()
    img_filterd = np.zeros((img.shape[0],img.shape[1]))
    kernel = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
    kernel_pad = np.zeros((4,4))
    for i in range(4):
        for j in range(4):
            if i>=1 and j>=1:
                kernel_pad[i][j] = kernel[i-1][j-1]
    #Procedure of generate F(u,v)
    F = np.fft.fft2(img)
    F = np.fft.fftshift(F)

    #Procedure of generate H(u,v)
    H = cv2.copyMakeBorder(kernel_pad, 0 ,img.shape[0]-4, 0, img.shape[1]-4, cv2.BORDER_CONSTANT, None, 0)
    H = np.fft.fft2(H)
    H = np.fft.fftshift(H)
    #H = np.imag(H)

    G = F*H

    s1 = np.abs(G)
    s1_ang = np.angle(G)
    s2 = np.zeros(img.shape,dtype=complex)
    s1_real = s1*np.cos(s1_ang)
    s1_imag = s1*np.sin(s1_ang)
    s2.real = np.array(s1_real)
    s2.imag = np.array(s1_imag)
    g = np.fft.ifftshift(G)
    g = np.fft.ifft2(g)
    g = np.abs(g)
    end1 = time.time()
#(d)spatial-domain filtering
    start2 = time.time()
    img_filterd_s = convolution2d(img,kernel,0)
    img_filterd_s = np.abs(img_filterd_s)
    end2 = time.time()

    print("Time of frequency domain filtering is %f  s" % (end1 - start1))
    print("Time of Spatial domain filtering is %f  s" % (end2 - start2))
#(e)frequency-domain filtering without enforced odd symmetry
    H2 = cv2.copyMakeBorder(kernel, 0 ,img.shape[0]-3, 0, img.shape[1]-3, cv2.BORDER_CONSTANT, None, 0)
    H2 = np.fft.fft2(H)
    H2 = np.fft.fftshift(H)
    #H = np.imag(H)

    G2 = F*H2
    s1 = np.abs(G2)
    s1_ang = np.angle(G2)
    s2 = np.zeros(img.shape,dtype=complex)
    s1_real = s1*np.cos(s1_ang)
    s1_imag = s1*np.sin(s1_ang)
    s2.real = np.array(s1_real)
    s2.imag = np.array(s1_imag)
    g2 = np.fft.ifftshift(G2)
    g2 = np.fft.ifft2(g2)
    g2 = np.abs(g2)
    plt.figure()
    plt.subplot(2,2,1)
    plt.imshow(result, cmap = 'gray')
    plt.title('(a)Original image spectrum')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,2,2)
    plt.imshow(g, cmap = 'gray')
    plt.title('(b)Frequency domain filtering')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,2,3)
    plt.imshow(img_filterd_s, cmap = 'gray')
    plt.title('(c)Spatial domain filtering')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,2,4)
    plt.imshow(g2, cmap = 'gray')
    plt.title('(e)Without enforced odd symmetry')
    plt.xticks([]),plt.yticks([])
    plt.show()
