import numpy as np
import cv2
import scipy
from matplotlib import pyplot as plt
from PIL import Image
from skimage.filters import laplace

class HomomorphicFilter:

    def __init__(self, a = 0.5, b = 1.5):
        self.a = float(a)
        self.b = float(b)

    # Filters
    def __butterworth_filter(self, I_shape, filter_params):
        P = I_shape[0]/2
        Q = I_shape[1]/2
        U, V = np.meshgrid(range(I_shape[0]), range(I_shape[1]), sparse=False, indexing='ij')
        Duv = (((U-P)**2+(V-Q)**2)).astype(float)
        H = 1/(1+(Duv/filter_params[0]**2)**filter_params[1])
        return (1 - H)

    def __gaussian_filter(self, I_shape, filter_params):
        P = I_shape[0]/2
        Q = I_shape[1]/2
        H = np.zeros(I_shape)
        U, V = np.meshgrid(range(I_shape[0]), range(I_shape[1]), sparse=False, indexing='ij')
        Duv = (((U-P)**2+(V-Q)**2)).astype(float)
        H = np.exp((-Duv/(2*(filter_params[0])**2)))
        return (1 - H)

    # Methods
    def __apply_filter(self, I, H):
        H = np.fft.fftshift(H)
        I_filtered = (self.a + self.b*H)*I
        return I_filtered

    def filter(self, I, filter_params, filter='gaussian', H = None):
        #  Validating image
        if len(I.shape) is not 2:
            raise Exception('Improper image')

        # Take the image to log domain and then to frequency domain 
        I_log = np.log1p(np.array(I, dtype="float"))
        I_fft = np.fft.fft2(I_log)

        # Filters
        if filter=='butterworth':
            H = self.__butterworth_filter(I_shape = I_fft.shape, filter_params = filter_params)
        elif filter=='gaussian':
            H = self.__gaussian_filter(I_shape = I_fft.shape, filter_params = filter_params)
        elif filter=='external':
            print('external')
            if len(H.shape) is not 2:
                raise Exception('Invalid external filter')
        else:
            raise Exception('Selected filter not implemented')
        
        # Apply filter on frequency domain then take the image back to spatial domain
        I_fft_filt = self.__apply_filter(I = I_fft, H = H)
        I_filt = np.fft.ifft2(I_fft_filt)
        I = np.exp(np.real(I_filt))-1
        return np.uint8(I)

def calculate_hist(img):
    hist = cv2.calcHist([img], [0], None, [256], [0, 256])
    return hist

def histogram_equlization(img):
    hist = cv2.calcHist([img], [0], None, [256], [0, 256])
    size = img.shape
    hs_img = np.zeros((size[0],size[1]))
    pr = np.zeros(len(hist))
    for i in range(len(hist)):
        pr[i] = hist[i] / (size[0]*size[1])
    for i in range(size[0]):
        for j in range(size[1]):
            hs_img[i][j]=round(255*np.sum(pr[1:img[i][j]]))
    hs_img = np.array(hs_img).astype("uint8")
    return hs_img 

def high_frequency_emphasis(img):
    img_fft = np.fft.fft2(img)
    img_fft = np.fft.fftshift(img_fft)
    #High-pass Gaussian filter
    (P, Q) = img_fft.shape
    H = np.zeros((P,Q))
    D0 = 40
    for u in range(P):
        for v in range(Q):
            H[u, v] = 1.0 - np.exp(- ((u - P / 2.0) ** 2 + (v - Q / 2.0) ** 2) / (2 * (D0 ** 2)))
    k1 = 0.75 ; k2 = 1
    HFEF = k1 + k2 * H 
    
    # Apply High-frequency emphasis
    HFE = img_fft * HFEF
    img_new = np.fft.ifftshift(HFE)
    img_new = np.fft.ifft2(img_new)
    img_new = np.abs(img_new)
    img_new = img_new.astype('uint8')
    return img_new

if __name__ == "__main__":
    img1 = cv2.imread("Einstein.tif")
    img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    img2 = cv2.imread("phobos.tif")
    img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    img_new = high_frequency_emphasis(img1)
    hist_img = cv2.equalizeHist(img1)

    #homographic filter
    homo_filter = HomomorphicFilter(a = 0.75, b = 1.25)
    img_filtered = homo_filter.filter(I=img1, filter_params=[80,2])
    img_filtered2 = cv2.equalizeHist(img_filtered)

    #laplace    
    laplace_filter = cv2.Laplacian(img2,cv2.CV_16S,ksize=3)
    laplace_filter = cv2.convertScaleAbs(laplace_filter)
    img3 = img2 + laplace_filter
    img4 = cv2.equalizeHist(img3)


    org_hist = calculate_hist(img2)
    img_new_hist = calculate_hist(img3)
    hist_img_hist = calculate_hist(img3 )
    plt.figure()
    plt.subplot(2,3,1)
    plt.imshow(img1, cmap = 'gray')
    plt.title('Einstein')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,3,2)
    plt.imshow(img_new, cmap = 'gray')
    plt.title('Einstein_enhanced')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,3,3)
    plt.imshow(hist_img, cmap = 'gray')
    plt.title('Histogram equlization')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,3,4)
    plt.imshow(img2, cmap = 'gray')
    plt.title('Phobos')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,3,5)
    plt.imshow(img3, cmap = 'gray')
    plt.title('Phobos_enhanced')
    plt.xticks([]),plt.yticks([])
    plt.subplot(2,3,6)
    plt.imshow(img4, cmap = 'gray')
    plt.title('Histogram equalization')
    plt.xticks([]),plt.yticks([])
    plt.show()


    # cv2.imwrite("Einstein_enhanced.png",img_new)
    # cv2.imwrite("Einstein_enhanced_histequal.png",hist_img)
    # cv2.imwrite("Phobos_enhanced.png",img3)
    # cv2.imwrite("Phobos_enhanced_histequal.png",img4)
    # cv2.imwrite("laplace_filter.png",img3)
    # # plt.imshow(img_filtered, cmap = 'gray')
    # # plt.xticks([]),plt.yticks([])
    # # plt.show()